﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Dot7.ServiceTableAdapters;
using Dot7.common;

namespace Dot7.Controllers
{
    public class Restaurant_MainController : ApiController
    {
        [HttpGet]
        public IEnumerable<Restaurant> getRestaurants(string id)
        {
            List<Restaurant> list = new List<Restaurant>();
            GetRestaurantsTableAdapter gs = new GetRestaurantsTableAdapter();
            foreach (var item in gs.GetRestaurants(id))
            {
                list.Add(new Restaurant { key = item.Key, RestaurantName = item.Restaurant_Name, Time = item.Time, Rating = item.Rating, ImageURL = item.ImageURL, Cuisines = item.Cuisines, isFavourite = item.isFavourite });

            }
            return list;
        }
    }
}
