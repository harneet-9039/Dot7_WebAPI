﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dot7.common
{
    public class Login
    {
        public string LoginID { get; set; }
        public string password { get; set; }
        
    }

    public class Register
    {
        public string LoginID { get; set; }
        public string password { get; set; }
        public string Name { get; set; }
    }

    public class Restaurant
    {
        public Guid key { get; set; }
        public string RestaurantName { get; set; }
        public string Time { get; set; }
        public string ImageURL { get; set; }
        public string Rating { get; set; }
        public string Cuisines { get; set; }
        public string isFavourite { get; set; }
    }

    public class Token
    {
        public string token { get; set; }
    }

  
    
}
